-- phpMyAdmin SQL Dump
-- version 3.1.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 24-10-2014 a las 00:08:12
-- Versión del servidor: 5.1.30
-- Versión de PHP: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `sg_modulo_vivienda`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `activa`
--

CREATE TABLE IF NOT EXISTS `activa` (
  `id_activa` int(10) NOT NULL,
  `nombre` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_activa`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Volcar la base de datos para la tabla `activa`
--

INSERT INTO `activa` (`id_activa`, `nombre`) VALUES
(1, 'activado'),
(2, 'desactivado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `deplazado`
--

CREATE TABLE IF NOT EXISTS `deplazado` (
  `id_des` int(10) NOT NULL,
  `estado` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_des`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Volcar la base de datos para la tabla `deplazado`
--

INSERT INTO `deplazado` (`id_des`, `estado`) VALUES
(1, 'si'),
(2, 'no');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `madre`
--

CREATE TABLE IF NOT EXISTS `madre` (
  `id_madre` int(10) NOT NULL,
  `situacion` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_madre`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Volcar la base de datos para la tabla `madre`
--

INSERT INTO `madre` (`id_madre`, `situacion`) VALUES
(1, 'si'),
(2, 'no');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personas`
--

CREATE TABLE IF NOT EXISTS `personas` (
  `cedula` int(15) NOT NULL,
  `nombres` varchar(30) DEFAULT NULL,
  `apellidos` varchar(30) DEFAULT NULL,
  `dirreccion` varchar(30) DEFAULT NULL,
  `barrio` varchar(30) DEFAULT NULL,
  `celular` varchar(20) DEFAULT NULL,
  `codigo` int(10) DEFAULT NULL,
  `N_caja` varchar(20) DEFAULT NULL,
  `fecha_ingreso` date DEFAULT NULL,
  `Observaciones` varchar(180) DEFAULT NULL,
  `id_territorio` int(10) DEFAULT NULL,
  `sisben` varchar(30) DEFAULT NULL,
  `ced_castatral` varchar(30) DEFAULT NULL,
  `id_madre` int(10) DEFAULT NULL,
  `id_des` int(10) DEFAULT NULL,
  `id_ries` int(10) DEFAULT NULL,
  PRIMARY KEY (`cedula`),
  KEY `FK_personas` (`codigo`),
  KEY `FK_personas1` (`id_territorio`),
  KEY `FK_personas2` (`id_madre`),
  KEY `FK_personas3` (`id_des`),
  KEY `FK_personas4` (`id_ries`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Volcar la base de datos para la tabla `personas`
--

INSERT INTO `personas` (`cedula`, `nombres`, `apellidos`, `dirreccion`, `barrio`, `celular`, `codigo`, `N_caja`, `fecha_ingreso`, `Observaciones`, `id_territorio`, `sisben`, `ced_castatral`, `id_madre`, `id_des`, `id_ries`) VALUES
(20332990, 'Maria Roselena           ', 'Sanchez Camargo', 'CALLE 6E No 2-22 ', 'Chico I', '320 4659276', 7, '001', '2013-07-09', 'CONTACTO:Personalmente\r\nNO APLICA PARA MEJORAMIENTO\r\ncambio de proyecto \r\nprueba \r\n\r\n\r\n', 2, '', '', 2, 2, 1),
(20404474, 'Ana Silvia', 'Cabrejo', 'Cra 1 sur No 25-52', 'Cartagenita', '320 3168412', 7, '001', '2014-07-10', 'NO APLICA PARA MEJORAMIENTO', 1, NULL, NULL, 2, 2, 2),
(20525795, 'Mariela', 'Cardenas Tellez', 'Calle 5B No 4-28', 'Chico II', '', 7, '001', '2014-07-14', 'CONTACTO:Personalmente\r\nFALTA VISITA\r\n', 1, '', '', 2, 2, 1),
(35524458, 'Adriana', 'Hernandez Moreno    ', 'NO TIENE', '', '3118614131', 7, '001', '2014-10-03', 'CONTACTO:PERSONAL\r\nVivienda Nueva\r\n', 2, '', '', 2, 2, 1),
(89464930, 'ani', 'sdlflp', 'werty', 'werty', '12345jj567', 7, '2345', '2014-10-16', 'prueba', 1, '23456', '234ertyu', 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyec`
--

CREATE TABLE IF NOT EXISTS `proyec` (
  `id_proyecto` int(10) NOT NULL,
  `estado` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_proyecto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Volcar la base de datos para la tabla `proyec`
--

INSERT INTO `proyec` (`id_proyecto`, `estado`) VALUES
(1, 'Ejecutado'),
(2, 'En curso');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyectos`
--

CREATE TABLE IF NOT EXISTS `proyectos` (
  `id_proyectos` int(10) NOT NULL AUTO_INCREMENT,
  `codigo` int(10) NOT NULL,
  `nombre_de_proyecto` varchar(30) DEFAULT NULL,
  `observaciones` varchar(150) DEFAULT NULL,
  `id_proye` int(10) DEFAULT NULL,
  PRIMARY KEY (`codigo`),
  UNIQUE KEY `id_proyectos` (`id_proyectos`),
  KEY `FK_proyectos1` (`id_proye`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=8 ;

--
-- Volcar la base de datos para la tabla `proyectos`
--

INSERT INTO `proyectos` (`id_proyectos`, `codigo`, `nombre_de_proyecto`, `observaciones`, `id_proye`) VALUES
(1, 1, 'reubicados', NULL, 1),
(2, 2, '100 subsidios', NULL, 1),
(3, 3, '82 subsidios', NULL, 2),
(4, 4, '90 mejoramientos', NULL, 2),
(5, 5, '116 mejoramientos', NULL, 2),
(6, 6, 'lista de beneficiarios', NULL, 1),
(7, 7, 'Mejoramiento de vivenda', 'mejoramiento de vivenda', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `riesgo`
--

CREATE TABLE IF NOT EXISTS `riesgo` (
  `id_ries` int(10) NOT NULL,
  `estado` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_ries`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Volcar la base de datos para la tabla `riesgo`
--

INSERT INTO `riesgo` (`id_ries`, `estado`) VALUES
(1, 'si'),
(2, 'no');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `seguridad`
--

CREATE TABLE IF NOT EXISTS `seguridad` (
  `id_seguridad` int(15) NOT NULL,
  `id_rol` int(10) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `cedula` int(10) DEFAULT NULL,
  `tabla` varchar(30) DEFAULT NULL,
  `antes` varchar(100) DEFAULT NULL,
  `ahora` varchar(100) DEFAULT NULL,
  `nombre_usuario` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `puesto` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_seguridad`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Volcar la base de datos para la tabla `seguridad`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sg_mv_rol`
--

CREATE TABLE IF NOT EXISTS `sg_mv_rol` (
  `id_rol` int(10) NOT NULL,
  `rol` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_rol`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Volcar la base de datos para la tabla `sg_mv_rol`
--

INSERT INTO `sg_mv_rol` (`id_rol`, `rol`) VALUES
(1, 'administrador'),
(2, 'arquitecto');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `terri`
--

CREATE TABLE IF NOT EXISTS `terri` (
  `id_territorio` int(10) NOT NULL,
  `territorio` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id_territorio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Volcar la base de datos para la tabla `terri`
--

INSERT INTO `terri` (`id_territorio`, `territorio`) VALUES
(1, 'urbano'),
(2, 'rural');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `id_usuario` int(10) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(30) DEFAULT NULL,
  `apellido` varchar(30) DEFAULT NULL,
  `telefono` int(15) DEFAULT NULL,
  `correo` varchar(30) DEFAULT NULL,
  `puesto` varchar(30) DEFAULT NULL,
  `alias` varchar(30) DEFAULT NULL,
  `pass` varchar(30) DEFAULT NULL,
  `id_rol` int(10) DEFAULT NULL,
  `cedula` int(15) NOT NULL,
  `id_activa` int(10) DEFAULT NULL,
  PRIMARY KEY (`id_usuario`,`cedula`),
  KEY `FK_usuario` (`id_rol`),
  KEY `FK_usuario1` (`id_activa`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=5 ;

--
-- Volcar la base de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nombre`, `apellido`, `telefono`, `correo`, `puesto`, `alias`, `pass`, `id_rol`, `cedula`, `id_activa`) VALUES
(1, 'andy', 'camargo', 2147483647, 'apanda_3@hotmail.com', 'ingeniero', 'admi', '12345', 1, 1014210492, 1),
(2, 'andy', 'camargo', 1234567, 'andysan18@hotmail.com', 'ingeniero', 'andy', '1234', 2, 1014210493, 1),
(3, 'prueba', 'ma', 1234657, 'jklfsjflksajflkña', 'hdsjkf', 'prueba', '1234', 1, 102145125, 2),
(4, 'andy leandro', 'camargo camargo', 5449087, 'akjdsahdajskh', 'arquitecto', 'admini', '12345', 1, 123456789, 1);

--
-- Filtros para las tablas descargadas (dump)
--

--
-- Filtros para la tabla `personas`
--
ALTER TABLE `personas`
  ADD CONSTRAINT `FK_personas` FOREIGN KEY (`codigo`) REFERENCES `proyectos` (`codigo`),
  ADD CONSTRAINT `FK_personas1` FOREIGN KEY (`id_territorio`) REFERENCES `terri` (`id_territorio`),
  ADD CONSTRAINT `FK_personas2` FOREIGN KEY (`id_madre`) REFERENCES `madre` (`id_madre`),
  ADD CONSTRAINT `FK_personas3` FOREIGN KEY (`id_des`) REFERENCES `deplazado` (`id_des`),
  ADD CONSTRAINT `FK_personas4` FOREIGN KEY (`id_ries`) REFERENCES `riesgo` (`id_ries`);

--
-- Filtros para la tabla `proyectos`
--
ALTER TABLE `proyectos`
  ADD CONSTRAINT `FK_proyectos1` FOREIGN KEY (`id_proye`) REFERENCES `proyec` (`id_proyecto`);

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `FK_usuario` FOREIGN KEY (`id_rol`) REFERENCES `sg_mv_rol` (`id_rol`),
  ADD CONSTRAINT `FK_usuario1` FOREIGN KEY (`id_activa`) REFERENCES `activa` (`id_activa`);
